CREATE DATABASE ETLDemo
GO

USE ETLDemo

DROP TABLE IF EXISTS users

CREATE TABLE [dbo].[users](
	[id] [int] NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Username] [nvarchar](50) NOT NULL,
	[Email] [nvarchar](50) NOT NULL,
	[Phone] [nvarchar](50) NOT NULL,
	[City] [nvarchar](50) NOT NULL,
	[Street] [nvarchar](50) NOT NULL,
	[Suite] [nvarchar](50) NOT NULL,
	[Latitude] [float] NOT NULL,
	[Longitude] [float] NOT NULL
) ON [PRIMARY]
GO

USE [ETLDemo]
GO
CREATE USER [petluser] FOR LOGIN [petluser] WITH DEFAULT_SCHEMA=[dbo]
GO

USE [ETLDemo]
GO
ALTER ROLE [db_owner] add MEMBER [petluser]
GO

--========================================================

Postgresql code

CREATE DATABASE ETLDemo
GO

USE ETLDemo

DROP TABLE IF EXISTS users

CREATE TABLE [dbo].[users](
	[id] [int] NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[Username] [varchar](50) NOT NULL,
	[Email] [varchar](50) NOT NULL,
	[Phone] [varchar](50) NOT NULL,
	[City] [varchar](50) NOT NULL,
	[Street] [varchar](50) NOT NULL,
	[Suite] [varchar](50) NOT NULL,
	[Latitude] [float] NOT NULL,
	[Longitude] [float] NOT NULL
) ON [PRIMARY]
GO

