
import folium
import json
import geopy
import pandas as pd
from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    users_dataFrame = pd.read_csv('C:\\RI_WrokProjects\\final_Proj\\petldemo\\petldemo\\src\\users.csv')
    latitude = -37.3159
    longitude = 81.1496
    map_test1 = folium.Map(location=[latitude,longitude], zoom_start=13, tiles='Stamen Terrain')
    incidents_loc = folium.map.FeatureGroup()
    latitudes = list(users_dataFrame.Latitude)
    longitudes = list(users_dataFrame.Longitude)
    labels = list(users_dataFrame.City)
    #df_accident1.head(2)
    #for lat, lng, label in zip(latitudes, longitudes, labels):
    for lat, lng, label in zip(latitudes, longitudes,labels, ):
        #folium.CircleMarker([lat, lng], popup=label,color='blue',fill=True).add_to(map_test)
        folium.CircleMarker(location=[lat,lng], color='blue',fill=True,popup=label).add_to(map_test1)
    # add incidents to map
    map_test1.add_child(incidents_loc)
    #map_test1.save('/templates/saved.html')
    map_path = app.root_path + '\\' + 'static\\map_test.html'
    map_test1.save(map_path)
    return render_template('index.html')



app.run(port=5999, host='0.0.0.0' )