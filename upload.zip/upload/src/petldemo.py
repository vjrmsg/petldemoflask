import os
import sys
import petl
import pymssql
import configparser
import requests
import datetime
import json
import decimal
import pandas as pd
import MySQLdb
import openpyxl
import sqlite3
import psycopg2


pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', 1)
from warnings import simplefilter
# ignore all types of warnings
simplefilter(action='ignore', category=UserWarning)
simplefilter(action='ignore', category=FutureWarning)
# importing operating system
import os
from geopy.geocoders import Nominatim
import requests
from pandas.io.json import json_normalize
import matplotlib.cm as cm
import matplotlib.colors as colors
import folium 


from petl import look, fromdb,fromjson,fromdicts,unpackdict,cut, todb, rename, tocsv


# get data from configuration file
config = configparser.ConfigParser()
try:
    config.read('ETLDemo.ini')
    print('read success')
except Exception as e:
    print('could not read configuration file:' + str(e))
    sys.exit()

# read settings from configuration file
url = config['CONFIG']['url']
destServer = config['CONFIG']['server']
destDatabase = config['CONFIG']['database']
user =  config['CONFIG']['user']
password =  config['CONFIG']['password']
mysqldestDatabase = config['CONFIG']['database']
mysqluser =  config['CONFIG']['mysqluser']
mysqlpassword =  config['CONFIG']['mysqlpassword']
sqlitedestDatabase = config['CONFIG']['sqlitedb']
pgdestDatabase = config['CONFIG']['pgdb']
pguser =  config['CONFIG']['puser']
pgpassword =  config['CONFIG']['pgpassword']

# request data from URL
try:
    UserResponse = requests.get(url,verify=False)
    print ('UserResponse')
    print(destDatabase)
except Exception as e:
    print('could not make request:' + str(e))
    sys.exit()

#Extract
if (UserResponse.status_code == 200):
   data = json.loads(UserResponse.text)
   print(data)
   #data = json.loads(jsonurl.read())
   users_table = fromdicts(data)
   users_table

   users_table = unpackdict(users_table, 'address')
   users_table = unpackdict(users_table, 'geo')

    #select a few columns
   users_table = cut(users_table, 'id', 'name','username','email','phone','city','street','suite','lat','lng')

    #rename column headers
   users_table = rename(users_table, {'name':'Name','username':'Username','email':'Email','phone':'Phone','city':'City','street':'Street','suite':'Suite','lat':'Latitude', 'lng':'Longitude'})
       
   print(users_table)
    

   tocsv(users_table, 'users.csv')
   
   #print(users_dataFrame.head())

# load csv file to SQLServer DB
   try:
        userrecs = petl.io.csv.fromcsv('users.csv')
        #print(userrecs.head())
   except Exception as e:
        print('could not open users.csv:' + str(e))
        sys.exit()
   try:
        dbConnection = pymssql.connect(user=user,password=password,server=destServer,database=destDatabase)
   except Exception as e:
        print('could not connect to database:' + str(e))
        sys.exit()

    # populate users database table
   try:
        petl.io.todb (userrecs,dbConnection,'users')
        print ('***** User csv data successfully imported into ENT-AP-VJTEST1 SQLServer *****')
   except Exception as e:
        print('could not write to database:' + str(e))
        print (userrecs)


# load csv file to mysql database
   try:
        userrecs = petl.io.csv.fromcsv('users.csv')
        print(userrecs.head())
   except Exception as e:
        print('could not open users.csv:' + str(e))
        sys.exit()
   try:
        dbConnection = MySQLdb.connect(password=mysqlpassword,database=mysqldestDatabase,user=mysqluser)
        print('connected mysql')
   except Exception as e:
        print('could not connect to database:' + str(e))
        sys.exit()

    # populate users database table
   try:
        #petl.io.todb (userrecs,dbConnection,'users')
        dbConnection.cursor().execute('SET SQL_MODE=ANSI_QUOTES')
        petl.todb(userrecs, dbConnection, 'users')
        print ('***** User csv data successfully imported into ENT-AP-VJTEST1 mysql *****')
   except Exception as e:
        print('could not write to database:' + str(e))
        print (userrecs)

# load csv file to sqlite database
   try:
        
        userrecs = petl.io.csv.fromcsv('users.csv')
        print(userrecs.head())
   except Exception as e:
        print('could not open users.csv:' + str(e))
        sys.exit()
   try:
        dbConnection = sqlite3.connect(database=sqlitedestDatabase)
        print('connected sqlite3')
   except Exception as e:
        print('could not connect to database:' + str(e))
        sys.exit()

    # populate users database table
   try:
        #petl.io.todb (userrecs,dbConnection,'users')
        #dbConnection.cursor().execute('SET SQL_MODE=ANSI_QUOTES')
        petl.io.todb(userrecs, dbConnection, 'users')
        print ('***** User csv data successfully imported into ENT-AP-VJTEST1 sqlite3 main database *****')
   except Exception as e:
        print('could not write to database:' + str(e))
        print (userrecs)

# load csv file postgresql data 
   try:
        if (UserResponse.status_code == 200):

          pgdata = json.loads(UserResponse.text)
               #print(data)
               #data = json.loads(jsonurl.read())
          pgusers_table = fromdicts(pgdata)
               #users_table

          pgusers_table = unpackdict(pgusers_table, 'address')
          pgusers_table = unpackdict(pgusers_table, 'geo')

               #select a few columns
          pgusers_table = cut(pgusers_table, 'id', 'name','username','email','phone','city','street','suite','lat','lng')

               #rename column headers
          pgusers_table = rename(pgusers_table, {'name':'name','username':'username','email':'email','phone':'phone','city':'city','street':'street','suite':'suite','lat':'latitude', 'lng':'longitude'})

               #print(users_table)
               

          # tocsv(users_table, 'users.csv')
     
          tocsv(pgusers_table, 'pgusers.csv')
          #users_dataFrame = pd.read_csv('pgusers.csv')
          pguserrecs = petl.io.csv.fromcsv('pgusers.csv')
          print(pguserrecs.head())
   except Exception as e:
        print('could not open pgusers.csv:' + str(e))
        sys.exit()
   try:
        
        dbConnection = psycopg2.connect(dbname=pgdestDatabase, user=pguser, password=pgpassword)
      
        print('connected postgresql')
   except Exception as e:
        print('could not connect to database:' + str(e))
        sys.exit()

    # populate users database table
   try:
        petl.io.todb (pguserrecs,dbConnection,'users')
        print ('***** User csv data successfully imported into ENT-AP-VJTEST1 postgresql main database *****')
   except Exception as e:
        print('could not write to database:' + str(e))
        print (userrecs)




#map_test1.show()





     

